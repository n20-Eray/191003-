﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrow : MonoBehaviour
{
    Vector3 position;

    // Start is called before the first frame update
    void Start()
    {
        gameObject.GetComponent<Arrow>().enabled = true;
        position = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        position.x += -5 * Time.deltaTime;
        transform.position = position;

        if (transform.position.x < -33.0f)
        {
            gameObject.transform.Translate(70f, 0f, 0f);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag.Equals("Player"))
        {
            OnDestroy();
        }        
    }

    void OnDestroy()
    {
        GameObject[] objects = GameObject.FindGameObjectsWithTag("Arrow");
        for (int i = 0; i < objects.Length; i++)
            Destroy(objects[i]);
    }
}
