﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMove : MonoBehaviour
{
    public float movePower = 6f;
    public float jumpPower = 8f;
    public Sprite nextSprite;
    public Sprite dieSprite;
    public Sprite runSprite1;
    public Sprite runSprite2;
    Rigidbody2D rigid;

    bool isJumping = false;

    // Start is called before the first frame update
    void Start()
    {
        gameObject.GetComponent<CharacterMove>().enabled = true;
        rigid = gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Jump"))
        {
            isJumping = true;
        }
    }

    private void FixedUpdate()
    {
        Move();
        Jump();
    }

    void Move ()
    {
        StartCoroutine("Running");
        Vector3 moveVelocity = Vector3.zero;
        if (Input.GetAxisRaw("Horizontal") < 0)
        {
            moveVelocity = Vector3.left;
            transform.localScale = new Vector3(-1, 1, 1);
        }
        else if (Input.GetAxisRaw("Horizontal") > 0)
        {
            moveVelocity = Vector3.right;
            transform.localScale = new Vector3(1, 1, 1);
        }
        transform.position += moveVelocity * movePower * Time.deltaTime;

    }

    void Jump()
    {
        if (!isJumping)
            return;
        rigid.velocity = Vector2.zero;

        Vector2 jumpVelocity = new Vector2(0, jumpPower);
        rigid.AddForce(jumpVelocity, ForceMode2D.Impulse);

        isJumping = false;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        StopCoroutine("Running");
        if (other.gameObject.tag.Equals("Arrow"))
        {
            gameObject.GetComponent<SpriteRenderer>().sprite = dieSprite;
            transform.Rotate(0.0f, 0.0f, -90.0f);
            gameObject.GetComponent<CharacterMove>().enabled = false;
        }
        if (other.gameObject.tag.Equals("Box"))
        {
            gameObject.GetComponent<SpriteRenderer>().sprite = nextSprite;
            GameObject.Find("arrows").SendMessage("OnDestroy");
            gameObject.GetComponent<CharacterMove>().enabled = false;
        }
    }

    IEnumerator Running()
    {
        gameObject.GetComponent<SpriteRenderer>().sprite = runSprite1;
        yield return new WaitForSeconds(1);
        gameObject.GetComponent<SpriteRenderer>().sprite = runSprite2;
        yield return new WaitForSeconds(1);
    }
}
